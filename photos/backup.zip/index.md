---
title: photos
type: photos
noDate: 'true'
fancybox: false
---
<link rel="stylesheet" href="ins.css">
<link rel="stylesheet" href="photoswipe.css"> 
<link rel="stylesheet" href="default-skin/default-skin.css">
<link rel="stylesheet" href="style.css">
<script src="photoswipe.min.js"></script>
<script src="photoswipe-ui-default.min.js"></script>


<div class="photos-btn-wrap">
  <a class="photos-btn active" href="javascript:void(0)" target="_blank" rel="external">Photos</a>
</div>
<div class="instagram itemscope">
  <a href="http://junono.com" target="_blank" class="open-ins">图片正在加载中…</a>
</div>
<script>
  (function() {
    var loadScript = function(path) {
      var $script = document.createElement('script')
      document.getElementsByTagName('body')[0].appendChild($script)
      $script.setAttribute('src', path)
    }
    setTimeout(function() {
        loadScript('ins.js')
    }, 0)
  })()
</script>

<!-- <div>
    <ul class="nav nav-tabs nav-justified" style="margin-top:-100px;">
	    <li id="li_album" class="active"><a onclick="to_album()">相册</a></li>
	    <li id="li_vlog"><a onclick="to_vlog()">视频</a></li>
    </ul>
</div>

<div class="photos-btn-wrap">
  <a class="photos-btn active" href="javascript:void(0)" target="_blank" rel="external">Photos</a>
</div>
<div class="instagram itemscope">
  <a href="http://junono.com" target="_blank" class="open-ins">图片正在加载中…</a>
</div>
 
<script>
  (function() {
    var loadScript = function(path) {
      var $script = document.createElement('script')
      document.getElementsByTagName('body')[0].appendChild($script)
      $script.setAttribute('src', path)
    }
    setTimeout(function() {
        loadScript('ins.js')
    }, 0)
  })()
</script>

<script>
  function to_vlog(){
      document.getElementById('1').style.display='none';
      document.getElementById('2').style.display='block';
      document.getElementById('li_vlog').setAttribute('class','active');
      document.getElementById('li_album').setAttribute('class','');
    }
    
  function to_album(){
      document.getElementById('1').style.display='block';
      document.getElementById('2').style.display='none';
      document.getElementById('li_album').setAttribute('class','active');
      document.getElementById('li_vlog').setAttribute('class','');
    }
</script> -->